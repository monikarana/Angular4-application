import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-ap',
  templateUrl: './add-ap.component.html',
  styleUrls: ['./add-ap.component.css']
})
export class AddApComponent implements OnInit {
  constructor() {}
  ngOnInit() {
  }

}
