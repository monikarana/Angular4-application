import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intel-nav-bar',
  templateUrl: './intel-nav-bar.component.html',
  styleUrls: ['./intel-nav-bar.component.css']
})
export class IntelNavBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
